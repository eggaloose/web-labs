Deps:
    nodejs: 20

How to run:
    user npm start cmd